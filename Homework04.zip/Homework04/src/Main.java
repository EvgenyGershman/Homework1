import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Проект 1: ");
        Scanner scanner = new Scanner(System.in);
        System.out.println("neuer Benutzer tippt dreistellige Zahl ein : ");
        int a = scanner.nextInt();
        System.out.println(a/100);
        System.out.println(a/10%10);
        System.out.println(a%10);
        System.out.println("Проект 2");
        Random random = new Random();
        int b = random.nextInt(999);
        int c = random.nextInt(999);
        int d = random.nextInt(999);
        System.out.println(" Betrag generieren = " + b);
        System.out.println(" Betrag generieren = " + c);
        System.out.println(" Betrag generieren = " + b);
        System.out.println(" Die Summe generierten Zahlen = " + (b + c +d));
        System.out.println(" Die Addition von generierten Zahlen = " + b * c * d);


    }
}