public class Main {
    public static void main(String[] args) {
        System.out.println("Georg Planck");
        System.out.println("Age 33");
        System.out.println("Height 180 cm");
        System.out.println();
        System.out.println("Axel Springel");
        System.out.println("Age 25");
        System.out.println("Height 165");
        System.out.println();
        System.out.println("Max Pick");
        System.out.println("Age 65");
        System.out.println("Height 175");
        System.out.println();
        System.out.printf("%.2f, %.2f, %.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.println("-");
        System.out.print("I");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.println("I");
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");


    }
}